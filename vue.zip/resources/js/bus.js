import Vue from 'vue'
export const events = new Vue()
